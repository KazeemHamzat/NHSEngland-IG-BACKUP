## {{page-title}}

All proposed assets for C&TA Sprint 1 are found here: <a href='https://simplifier.net/guide/nhs-england-implementation-guide-stu1?version=1.0.0-sprint-1-review' target="_blank"> Clinical and Technical Assurance Sprint 1 Documentation Pack </a>