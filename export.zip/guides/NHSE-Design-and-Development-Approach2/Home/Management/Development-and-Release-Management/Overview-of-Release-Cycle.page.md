## {{page-title}}

The section details the NHS England IG release cycle and how the various versions are defined.

### Overview Of Cycle

The diagram below illustrates how the NHS England IG Release cycle works and is an abstract view of the way it is released. This is an evolving process, and the diagram only shows one release cycle of a sequence of a repeating process. 

<div align="center">
<iframe src="https://drive.google.com/file/d/1XGUofzAJDvE4F4HB3fY8xvQPuEKnbtd6/preview" width="500" height="520" allow="autoplay" title="Overview of Release Process"></iframe>
</div>