## {{page-title}}

### Prerequisites

Once the package has been created the IG can be published. Within the IG editor:
1. Click the hamburger. Click Settings

{{render:Settings}}

<br>

- Add the title NHS England Design and Development Approach. 
- Add a description
- Change the scope to point to the newly created package and click save.

<br>

{{render:TitleandDescription}}