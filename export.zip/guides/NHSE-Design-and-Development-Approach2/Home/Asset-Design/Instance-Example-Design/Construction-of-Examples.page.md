## {{page-title}}

Each example SHOULD have the minimum amount of information necessary to convey the intended message whilst ensuring it is still a valid resource or extension. If there any agreed Clinical scenario(s), then these SHALL be represented in examples.

### Meta Element

The <code>Resource.meta</code> element SHALL NOT be used for Examples.

---

