### An example of an Snippet Example

<nocheck>
<div class="tab">
   <button class="tablinks" onclick="openTab(event, 'Table View')">Table View</button>
   <button class="tablinks active" onclick="openTab(event, 'XML View')">XML View</button>
  <button class="tablinks" onclick="openTab(event, 'JSON View')">JSON View</button>
</div>

<div id="Table View" class="tabcontent">
  <h3>Table View</h3>
{{table:UKCore-Condition-Sn-Extension-CodingSCT-MoleOfSkin-Example, snapshot}}
</div>

<div id="XML View" class="tabcontent" style="display:block">
  <h3>XML View</h3>
{{xml:UKCore-Condition-Sn-Extension-CodingSCT-MoleOfSkin-Example, snapshot}}
</div>

<div id="JSON View" class="tabcontent">
  <h3>JSON View</h3>
{{json:UKCore-Condition-Sn-Extension-CodingSCT-MoleOfSkin-Example, snapshot}}
</div>
</nocheck>

---
