# {{page-title}}

Examples help clarify the complexities of FHIR for the reader. For this reason, the NHS England IG MAY have an example for every Resource and Extension.

---

