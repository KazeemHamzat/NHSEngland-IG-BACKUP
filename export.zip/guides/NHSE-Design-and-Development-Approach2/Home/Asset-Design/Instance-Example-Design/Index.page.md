# {{page-title}}

Examples help clarify the complexities of FHIR for the reader. For this reason, the NHS England IG SHALL have at least one example for every Resource and Extension. Snippets of code may also be needed to convey certain information on specific elements which may be general to may Resources, or creating a full Resource would complicate the example.  This section details how examples are constructed, named and referenced in the the NHS England IG.

<br><br>
