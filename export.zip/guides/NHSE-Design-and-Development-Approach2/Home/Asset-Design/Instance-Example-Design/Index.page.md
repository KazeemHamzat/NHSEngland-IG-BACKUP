# {{page-title}}

Examples help clarify the complexities of FHIR for the reader. For this reason, there SHALL be an example for every Profile. Each Extension MAY have an example.

---