## {{page-title}}

<table class="assets">
<tr>
<th class="width20">Date</th>
<th class="width20">IG Version</th>
<th class="width20">NHSE Package Version</th>
<th class="width20">UK Core Version</th>
<th class="width20">FHIR Version</th>
</tr>
<tr>
<td>9th November 2023</td>
<td>1.0.0</td>
<td>STU1 1.0.0</td>
<td>STU3 0.0.6</td>
<td>4.0.1</td>
</tr>
<tr>
<td colspan="5">Intial release of the FGM Implementation guide following completion of NHS England IG Sprint 1.</td>
</tr>
<tr>
<td colspan="5"><b>Changes for this version</b>
<br />
<ul>
<li>Active assets following Sprint 1 Final Disposition Call</li>
</ul>
</td>
</tr>
</table>