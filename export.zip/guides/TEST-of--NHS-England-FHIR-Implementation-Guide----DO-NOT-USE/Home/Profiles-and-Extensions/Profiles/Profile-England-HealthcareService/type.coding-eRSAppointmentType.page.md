## `type.coding:eRSAppointmentType`

<b>Definition:</b>

Appointment type e.g. telephone/video (only applicable and mandatory if Service Type is Appointment Request, not applicable to Service Type of Triage Request)

---

