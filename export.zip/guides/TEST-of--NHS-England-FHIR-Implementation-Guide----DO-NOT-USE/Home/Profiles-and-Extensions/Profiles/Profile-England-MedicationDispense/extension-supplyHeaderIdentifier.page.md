## `extension:supplyHeaderIdentifier`

<b>Definition:</b><br>

Identifier of the SupplyHeader (v3) object. The prescription in the context of a Dispense Notification or Claim. Mandatory for EPS interactions.

---