    ## `generalPractitioner:registeredGPPractice`

<b>Definition:</b>

Patient's registered GP Practice. Use V81998 for no registered practice and V81999 for not known as per NHS Data Dictionary guidelines.

---