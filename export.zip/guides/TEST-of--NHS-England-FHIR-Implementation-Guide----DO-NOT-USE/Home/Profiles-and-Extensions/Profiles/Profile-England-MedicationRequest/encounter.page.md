## `encounter`

<b>Definition</b><br>

Encounter is required for secondary care prescriptions.

 ````   