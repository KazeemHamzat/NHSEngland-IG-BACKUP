## `prescriptionOrderItem`

<b>Definition:</b><br>  

Unique Id of the MedicationRequest within EPS.

 ```` 