## Downloads

<table class="regular assets">
<thead>
<tr>
<th>Current Release Package</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<td>Package</td>
<td>uk.nhsdigital.r4</td>
</tr>
<tr>
<td>Version</td>
<td>2.8.0</td>
</tr>
<tr>
<td>IG Package Url</td>
<td><a href="https://packages.simplifier.net/uk.nhsdigital.r4/-/uk.nhsdigital.r4-2.8.0.tgz">https://packages.simplifier.net/uk.nhsdigital.r4/-/uk.nhsdigital.r4-2.8.0.tgz</a></td>
</tr>
</tbody>
</table>