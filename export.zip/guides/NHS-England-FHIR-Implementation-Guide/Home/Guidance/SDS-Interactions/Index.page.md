## Design

Design specifications and requirements for Spine FHIR APIs including:

### Spine Directory Services (SDS)

Device and Endpoint endpoints providing Search interactions enabling:

* Look up a provider’s endpoint and ASID
* Look up a consumer’s own ASID