## Design overview

The SDS API design will follow the guiding design principle that the API seeks to hide legacy complexity where possible.

The SDS API will fully hide the consumer from details of the ldap query used to convey SDS information to and from Spine.
