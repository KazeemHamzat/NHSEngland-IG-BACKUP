## {{page-title}}

NHS Digital has defined the following operations.

- {{pagelink:process-message}}