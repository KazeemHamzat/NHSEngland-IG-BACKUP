### Extension-Spine-ActorRoleServiceOrSpecialty


| Conformance url |
|--
| https://fhir.nhs.uk/StructureDefinition/Extension-Spine-ActorRoleServiceOrSpecialty | 

<br>

<div class="tab">
<button class="tablinks active" onclick="openTab(event, 'Structure')">Structure</button>
<button class="tablinks" onclick="openTab(event, 'Examples')">Examples</button>
</div>
<div id="Structure" class="tabcontent" style="display:block">
  {{render: https://fhir.nhs.uk/StructureDefinition/Extension-Spine-ActorRoleServiceOrSpecialty}}

</div>
<div id="Examples" class="tabcontent">
  <h3>Examples</h3>
</div>