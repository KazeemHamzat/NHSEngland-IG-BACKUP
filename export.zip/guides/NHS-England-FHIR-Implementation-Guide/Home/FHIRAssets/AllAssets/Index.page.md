### All Assets
