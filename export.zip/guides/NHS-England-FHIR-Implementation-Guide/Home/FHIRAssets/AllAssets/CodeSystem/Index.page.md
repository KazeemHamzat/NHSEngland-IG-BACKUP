#### CodeSystem

- {{pagelink:England-APIErrorOrWarningCode}}
- {{pagelink:England-AppointmentCancellationReason}}