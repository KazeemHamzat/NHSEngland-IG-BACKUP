## `statusReason`

<b>Definition</b><br>

"This is generally only used for exception statuses such as `suspended` or `cancelled`. It is the clinical status reason for the cancellation.

This is mandatory for 'prescription-order-update' messages.

<br>

```json

    "statusReason": [{
            "coding": {
                "system": "https: //fhir.nhs.uk/CodeSystem/medicationrequest-status-reason",
                "code": "0001",
                "display": "Prescribing Error"
            }
        }
    ]

 ````       