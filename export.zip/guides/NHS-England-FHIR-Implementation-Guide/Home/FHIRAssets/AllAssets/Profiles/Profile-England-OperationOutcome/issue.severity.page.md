## `issue.severity`

<b>Definition:</b><br>

Indicates whether the issue indicates a variation from successful processing.

```json
 "severity": "error",
```

---

