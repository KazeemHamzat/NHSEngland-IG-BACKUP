## `SNOMED CT codes relating to COVID-19 Vaccination`

<b>Definition</b><br>

A complete list of SNOMED CT Codes relating to this profile can be found here [SNOMED CT codes relating to COVID-19 Vaccination](https://hscic.kahootz.com/gf2.ti/f/762498/92769925.1/DOCX/-/COVID19_Vaccination_Codes_20210211_v1.7.docx)

---