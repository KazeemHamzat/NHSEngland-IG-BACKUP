## `identifier:UBRN`

<b>Definition:</b><br>

Unique Booking Reference Number (12 digit number used as an internal and external identifier of the referral), known as "Booking Reference" Patient side

---