## `identifier:UBRN.system`
<br>

| | |
|----|----|
|Element Id|ServiceRequest.identifier:UBRN.system|
|[Cardinality](https://www.hl7.org/fhir/conformance-rules.html#cardinality)|1..1|
|Fixed Value|https://fhir.nhs.uk/Id/UBRN|
|[type](https://www.hl7.org/fhir/datatypes.html)|[uri](https://www.hl7.org/fhir/datatypes.html#uri)|

---