## `identifier:sdsUserId`

<b>Definition:</b>

Used with CIS2 and Spine

---

