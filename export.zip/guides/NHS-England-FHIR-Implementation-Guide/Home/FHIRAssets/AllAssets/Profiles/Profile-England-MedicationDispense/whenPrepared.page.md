## `whenPrepared`

<b>Definition:</b><br>

The time when the dispensed product was packaged and reviewed.

```json
"whenPrepared": "2004-09-16T16:30:00+00:00",

```

---