## `generalPractitioner:registeredGeneralMedicalPractitioner`

<b>Definition:</b>

This is to support legacy use cases where the patients GP is present