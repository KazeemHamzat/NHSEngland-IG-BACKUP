## Bindings (differential)

There are no bindings to England ValueSets.

---