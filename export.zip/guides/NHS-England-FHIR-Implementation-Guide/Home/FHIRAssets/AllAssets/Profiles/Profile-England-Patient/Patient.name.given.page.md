## `Patient.name.given`

<b>Definition:</b>

Given names, including any middle names.