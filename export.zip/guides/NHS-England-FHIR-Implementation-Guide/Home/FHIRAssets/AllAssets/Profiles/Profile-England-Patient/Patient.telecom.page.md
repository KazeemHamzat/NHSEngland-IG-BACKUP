## `Patient.telecom`

<b>Definition:</b>

