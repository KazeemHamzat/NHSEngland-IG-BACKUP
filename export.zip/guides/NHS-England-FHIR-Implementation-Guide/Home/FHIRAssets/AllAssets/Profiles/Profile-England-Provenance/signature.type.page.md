## `signature.type`

<b>Definition</b><br>

type must be provided. 

```json
"signature": [
        {
            "type": [
                {
                    "system": "urn:iso-astm:E1762-95:2013",
                    "code": "1.2.840.10065.1.12.1.1"
                }
            ]
        }
    ]
```

---