## `signature.when`

<b>Definition</b><br>

The dateTime the signature was signed. 

```json
"signature": [
        {
            "when": "2008-02-27T11:38:00+00:00"
        }
    ]
```

---


