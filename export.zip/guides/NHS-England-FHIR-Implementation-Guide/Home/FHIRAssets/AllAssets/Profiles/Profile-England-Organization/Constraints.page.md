## Constraints (differential)

More information about the constraints on the <code>UKCore-[profile]</code> profile can be found below.

<table class="assets">
<tr>
<th width="15%">Key</th>
<th width="10%">Severity</th>
<th width="30%">Expression</th>
<th width="45%">Human Description</th>
</tr>
<tr>
<td>nhsd-6</td>
<td>warning</td>
<td>display.exists()</td>
<td>partOf.display - a display name should be provided</td>
</tr>
</table>

---