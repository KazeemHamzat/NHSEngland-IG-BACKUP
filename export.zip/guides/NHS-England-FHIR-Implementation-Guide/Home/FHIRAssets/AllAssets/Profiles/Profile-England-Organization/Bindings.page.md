## Bindings (differential)

More information about the bindings to UK Core ValueSets can be found below.

<table class="assets">
<tr>
<th width="30%">Context</th>
<th width="20%">Strength</th>
<th width="50%">Link</th>
</tr>
<tr>
<td>Organization.type</td>
<td>Preferred</td>
<td>{{pagelink:ValueSet-England-OrganisationRole}}</td>
</tr>
</table>

---