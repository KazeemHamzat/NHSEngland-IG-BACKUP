## `name`

<b>Definition:</b>

The ODS/SDS name of the Organisation

```json
"name": "NHS NIGHTINGALE HOSPITAL YORKSHIRE AND THE HUMBER"
```

---

