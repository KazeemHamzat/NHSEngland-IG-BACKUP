##### NamingSystem-NHSMHSEndPoint

 {{tree:https://fhir.nhs.uk/Id/NHSMHSEndPoint, snapshot}}