#### ValueSet
- {{pagelink:UKCore-England-organisation-type}}
- {{pagelink:NHSDigital-OperationOutcome-Codes}}
- {{pagelink:organisation-role}}
- {{pagelink:NHSDigital-Message-Events}}
- {{pagelink:Message-Reason-Codes}}
- {{pagelink:NHSDataDictionaryClinicalSpecialty}}
- {{pagelink:covid-19-detection-of-virus}}
- {{pagelink:covid-19-detection-of-antibody}}
- {{pagelink:covid-19-detection-of-antigen}}
- {{pagelink:England-servicerequest-category}}

### Legacy

- {{pagelink:v3-npfit-nameuse-vs}}
- {{pagelink:v2-hscic-0200-NameType}}
