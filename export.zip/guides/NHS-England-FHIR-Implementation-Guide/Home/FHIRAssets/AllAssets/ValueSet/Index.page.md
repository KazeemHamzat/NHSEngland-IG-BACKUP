#### ValueSet


- {{pagelink:England-BARSMessageServiceRequestCategory}}
- {{pagelink:England-CareSettingType}}
- {{pagelink:England-ClinicalSpecialty}}
- {{pagelink:England-DMMedicationDispenseStatusReason}}
- {{pagelink:England-DMMedicationDispenseType}}
- {{pagelink:England-DMMedicationRequestCategory}}
- {{pagelink:England-DMMedicationRequestCourseOfTherapy}}
- {{pagelink:England-DMMedicationRequestStatusReason}}
- {{pagelink:England-DMPerformerSiteType}}
- {{pagelink:England-DMPrescriptionType}}
- {{pagelink:England-DMTaskBusinessStatus}}
- {{pagelink:England-DMTaskReasonCode}}
- {{pagelink:England-ERSAppointmentCancellationReasonCategory}}
- {{pagelink:England-ERSAppointmentType}}
- {{pagelink:England-ERSClinicType}}
- {{pagelink:England-ERSPriorityCategory}}
- {{pagelink:England-ERSReferralStateCategory}}
- {{pagelink:England-ERSSpecialty}}
- {{pagelink:England-ERSSpecialtyCategory}}
- {{pagelink:England-ImmunizationExplanationReason}}
- {{pagelink:England-LocationType}}
- {{pagelink:England-MedicationCode}}
- {{pagelink:England-MedicationDispenseCode}}
- {{pagelink:England-MessageEvents}}
- {{pagelink:England-MessageReasonCode}}
- {{pagelink:England-NHSDataModelAndDictionaryTreatmentFunctionCategory}}
- {{pagelink:England-ObservationCategory}}
- {{pagelink:England-OperationOutcomeCodes}}
- {{pagelink:England-OrganisationRole}}
- {{pagelink:England-PractitionerRoleCode}}
- {{pagelink:England-ReasonImmunizationNotAdministered}}
- {{pagelink:England-ServiceRequestCategory}}
- {{pagelink:England-ServiceRequestCategoryCodes}}
- {{pagelink:England-VaccinationProcedure}}
- {{pagelink:England-VaccineCode}}





- {{pagelink:UKCore-England-organisation-type}}
- {{pagelink:organisation-role}}
- {{pagelink:NHSDigital-Message-Events}}
- {{pagelink:Message-Reason-Codes}}
- {{pagelink:NHSDataDictionaryClinicalSpecialty}}
- {{pagelink:covid-19-detection-of-virus}}
- {{pagelink:covid-19-detection-of-antibody}}
- {{pagelink:covid-19-detection-of-antigen}}
- {{pagelink:England-servicerequest-category}}

### Legacy

- {{pagelink:v3-npfit-nameuse-vs}}
- {{pagelink:v2-hscic-0200-NameType}}
