### Extensions

|Extensions| Notes |
|--
|{{pagelink:Extension-SDS-ReliabilityConfiguration}}|Reliability and configuration information that can be used when calling a service endpoint.|
| {{pagelink:Extension-Spine-ActorRoleServiceOrSpecialty}} | |
