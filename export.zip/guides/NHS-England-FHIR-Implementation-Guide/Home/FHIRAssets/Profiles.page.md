### Profiles

This project is using the profiles shown below.

- {{pagelink:SDS-Device}}
- {{pagelink:SDS-Endpoint}}
- {{pagelink:NHSDigital-CapabilityStatement}}
- {{pagelink:NHSDigital-CommunicationRequest}}
- {{pagelink:NHSDigital-HealthcareService}} 
- {{pagelink:NHSDigital-Immunization}} 
- {{pagelink:NHSDigital-ImmunizationRecommendation}}
- {{pagelink:NHSDigital-Location-duplicate-2.md}} 
- {{pagelink:NHSDigital-MessageHeader}} 
- {{pagelink:NHSDigital-Observation}} 
- {{pagelink:NHSDigital-OperationOutcome.md}} 
- {{pagelink:NHSDigital-Organization}}  
- {{pagelink:NHSDigital-Patient}}  
- {{pagelink:NHSDigital-Practitioner}} 
- {{pagelink:NHSDigital-PractitionerRole}}

