### NamingSystems

Official Catalogues of OIDS in the UK 

[HL7 UK OID Catalogue](https://www.hl7.org.uk/standards/object-identifiers-oids/hl7-uk-issued-oids/)

[NPfIT OID Catalogue](https://data.developer.nhs.uk/dms/mim/4.2.00/External%20Documents/OID/NPfIT%20OID%20Catalogue.htm)

{{namingsystems}}
