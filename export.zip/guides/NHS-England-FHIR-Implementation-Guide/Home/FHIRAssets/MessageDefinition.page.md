### MessageDefinition

#### Diagnostics

- {{pagelink:unsolicited-observations}}

#### Medications

- {{pagelink:prescription-order}}
- {{pagelink:dispense-notification}}
- {{pagelink:vaccinations}}

#### Workflow

- {{pagelink:appointment}}
- {{pagelink:referral}}
- {{pagelink:documents}}
