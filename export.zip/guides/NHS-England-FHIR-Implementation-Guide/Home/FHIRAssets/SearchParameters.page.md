### Search Parameters

|SearchParameters|
|--
|{{pagelink:SearchParameter-SDS-ManagingOrganisation}}|A search parameter to query on the managing organisation of an Accredited System|