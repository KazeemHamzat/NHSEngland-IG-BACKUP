## `extension:agent`

<b>Definition:</b><br>
Is used as the author on request resources.

---