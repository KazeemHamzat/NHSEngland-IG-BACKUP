## `authoredOn`

 <b>Definition</b><br>

 Date and time the task was created.

 ```json
"authoredOn": "2020-12-21T17:03:20-00:00",
```


---