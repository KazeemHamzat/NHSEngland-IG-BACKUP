## `authoredOn`

<b>Definition</b><br>

Date and time the task was created.

---