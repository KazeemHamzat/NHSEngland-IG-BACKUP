## `note`

<b>Definition</b><br>

 **EPS Only**

This may contain cancellation reason.

**e-RS**

Used to add notes to the worklist items

---