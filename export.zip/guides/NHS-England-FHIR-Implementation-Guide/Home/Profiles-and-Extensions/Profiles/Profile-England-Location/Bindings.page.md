## Bindings (differential)

More information about the bindings to UK Core ValueSets can be found below.

<table class="assets">
<tr>
<th width="30%">Context</th>
<th width="20%">Strength</th>
<th width="50%">Link</th>
</tr>
<tr>
<td>Location.type</td>
<td>extensible</td>
<td>{{pagelink:ValueSet-England-LocationType}}</td>
</tr>
</table>

---