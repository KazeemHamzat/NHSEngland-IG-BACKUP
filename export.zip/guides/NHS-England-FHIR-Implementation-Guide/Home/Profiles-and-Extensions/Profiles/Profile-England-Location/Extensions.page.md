## Extensions

More information about the extensions can be found using the links below.

<table class="assets">
<tr>
<th width="20%">Extension</th>
<th width="20%">Context</th>
<th width="30%">Link</th>
<th width="30%">Comment</th>
</tr>
<tr>
<td>locationRole</td>
<td>Location.type</td>
<td>{{pagelink:Extension-England-ODSOrganizationRole}}</td>
<td></td>
</tr>
<tr>
<td>activePeriod</td>
<td>Location.type</td>
<td>{{pagelink:Extension-England-ODSOrganizationRoleActivePeriod}}</td>
<td></td>
</tr>
</table>

---