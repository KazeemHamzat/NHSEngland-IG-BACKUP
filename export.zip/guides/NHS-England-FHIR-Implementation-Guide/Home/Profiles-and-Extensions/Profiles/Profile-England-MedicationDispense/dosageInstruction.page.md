## `dosageInstruction`

<b>Definition:</b><br>

At present only the text element MUST be provided. It is recommended the guidance in FHIR Dose Syntax Implementation Guidance is followed.

---