## `extension:prescriptionNonDispensingReason`

<b>Definition:</b><br>

This is the reason a complete prescription was not dispensed, it is not the status of the individual line items, which is contained in MedicationDispense.statusReason.

---