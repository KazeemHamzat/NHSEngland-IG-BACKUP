## `telecom`

<b>Definition:</b>

List of contact points for the patient; for example, phone numbers or email addresses. When a patient tagged as `restricted` or `very restricted` is retrieved, all contact points are removed from the response.

```json
"telecom":  [
{
  "system": "phone",
  "use": "work",
  "value": "01632960587"
}
]
```

---