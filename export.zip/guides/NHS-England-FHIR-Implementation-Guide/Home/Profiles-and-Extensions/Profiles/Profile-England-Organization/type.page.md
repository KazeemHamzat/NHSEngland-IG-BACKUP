## `type`

<b>Definition:</b>

The Organisation types **MUST** be present and comes from the valueSet.

`type` will also include details on when these roles applied, the current status and a boolean to indicate the Organisations primary role. These extensions are for API's produced by NHS Digital one, the are not expected to be present in resources created by NHS providers or suppliers.

---

