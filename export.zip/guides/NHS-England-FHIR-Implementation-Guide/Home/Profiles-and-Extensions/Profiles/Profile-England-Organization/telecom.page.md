## `telecom`

<b>Definition:</b>

Contact phone numbers and address of the organisation.

---

