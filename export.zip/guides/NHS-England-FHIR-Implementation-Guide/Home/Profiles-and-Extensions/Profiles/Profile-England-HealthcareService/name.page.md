## `name`

<b>Definition:</b>

Name of the clinic or service.

```json
 "name": "SOMERSET BOWEL CANCER SCREENING CENTRE",
```

---

