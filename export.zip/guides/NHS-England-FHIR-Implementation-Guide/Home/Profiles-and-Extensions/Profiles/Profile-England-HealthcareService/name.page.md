## `name`

<b>Definition:</b>

Name of the clinic or service.

---

