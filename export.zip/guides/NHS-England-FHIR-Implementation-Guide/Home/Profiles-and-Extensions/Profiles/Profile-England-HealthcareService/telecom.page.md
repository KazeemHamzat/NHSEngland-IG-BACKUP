## `telecom`

<b>Definition:</b>

Contact details for the clinic or service.

```json
   "telecom": [
    {
      "system": "phone",
      "value": "0113 922 4984",
      "use": "work"
    },
    {
      "system": "email",
      "value": "directaddress@example.com",
      "use": "work"
    }
  ],
```

---

