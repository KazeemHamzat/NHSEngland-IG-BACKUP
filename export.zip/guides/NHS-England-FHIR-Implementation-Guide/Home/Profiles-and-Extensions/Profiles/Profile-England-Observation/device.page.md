## `device`

<b>Definition:</b><br>

Details of the [COVID-19 test kit](https://simplifier.net/resolve?target=simplifier&amp;scope=uk.nhsdigital.r4&amp;canonical=https://fhir.nhs.uk/Id/Covid19-TestKit) used. 

---