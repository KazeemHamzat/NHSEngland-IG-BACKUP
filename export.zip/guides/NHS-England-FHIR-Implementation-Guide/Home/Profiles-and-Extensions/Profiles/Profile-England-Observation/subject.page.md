## `category`

<b>Definition:</b><br>

The NHS Number will be an identifier reference which can be used with PDS FHIR API to return Patient demographics. If a local Patient is available, a reference to this will be present (e.g. "Patient/123")y.

```json
"subject": {
        "reference": "Patient/123",
        "identifier":  [
            {
                "system": "https://fhir.nhs.uk/Id/nhs-number",
                "value": "987123456"
            }
        ]
    },
```

---