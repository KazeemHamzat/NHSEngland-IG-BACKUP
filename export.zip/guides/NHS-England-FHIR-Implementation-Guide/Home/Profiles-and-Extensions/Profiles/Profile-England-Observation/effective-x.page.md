## `effective[x]`

<b>Definition:</b><br>

The date and time the result was asserted.

```json
 "effectiveDateTime": "2020-09-23T13:00:08.476+00:00"
```

---