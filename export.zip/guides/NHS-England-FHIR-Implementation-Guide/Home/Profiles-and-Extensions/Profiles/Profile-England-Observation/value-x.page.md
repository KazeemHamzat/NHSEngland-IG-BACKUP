## `value[x]`

<b>Definition:</b><br>

The COVID 19 test result. This is a SNOMED CT from the valueSet associated with the `code`, see [Observation Definition].(https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/ObservationDefinition/ObservationDefinition.guide.md)

---