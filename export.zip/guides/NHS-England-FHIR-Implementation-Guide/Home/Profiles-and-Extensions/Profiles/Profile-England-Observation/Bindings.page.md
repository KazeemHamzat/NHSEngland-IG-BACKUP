## Bindings (differential)

More information about the bindings to NHS England ValueSets can be found below.

<table class="assets">
<tr>
<th width="30%">Context</th>
<th width="20%">Strength</th>
<th width="50%">Link</th>
</tr>
<tr>
<td><code>Observation.category:COVID-TestPillar<code></td>
<td>required</td>
<td>{{pagelink:ValueSet-England-ObservationCategory}}</td>
</tr>
</table>

---