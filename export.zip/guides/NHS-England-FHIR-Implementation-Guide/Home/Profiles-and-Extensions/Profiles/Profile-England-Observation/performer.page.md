## `effective[x]`

<b>Definition:</b><br>

Who was responsible for asserting the observed value as "true".

---