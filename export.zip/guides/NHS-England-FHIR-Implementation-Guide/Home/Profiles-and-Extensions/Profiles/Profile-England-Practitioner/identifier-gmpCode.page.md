## `identifier:gmpCode`

<b>Definition:</b>

Formerly called GP General National Code (GNC).

---

