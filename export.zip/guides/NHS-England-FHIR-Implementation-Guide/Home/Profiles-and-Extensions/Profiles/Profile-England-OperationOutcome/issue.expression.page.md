## `issue.expression`

<b>Definition:</b><br>

FHIRPath of element(s) related to issue

---