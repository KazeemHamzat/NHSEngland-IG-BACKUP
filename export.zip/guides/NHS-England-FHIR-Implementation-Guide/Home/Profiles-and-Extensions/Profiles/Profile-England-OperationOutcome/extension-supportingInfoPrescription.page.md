## `extension:supportingInfoPrescription`

<b>Definition</b><br>

Information relevant to this OperationOutcome. For EPS signature verification failures resulting in release rejections this MUST be the prescription which is failing.


---