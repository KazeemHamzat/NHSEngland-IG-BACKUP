## Bindings (differential)

More information about the bindings to NHS England ValueSets can be found below.

<table class="assets">
<tr>
<th width="30%">Context</th>
<th width="20%">Strength</th>
<th width="50%">Link</th>
</tr>
<tr>
<td><code>OperationOutcome.issue.details.coding<code></td>
<td>extensible</td>
<td>{{pagelink:ValueSet-England-OperationOutcomeCode}}</td>
</tr>

</table>

---