## `extension:supportingInfo`

<b>Definition:</b><br>

Information relevant to this OperationOutcome. For EPS release rejections this may be the pharmacy which currently owns the prescription task/order.

---

