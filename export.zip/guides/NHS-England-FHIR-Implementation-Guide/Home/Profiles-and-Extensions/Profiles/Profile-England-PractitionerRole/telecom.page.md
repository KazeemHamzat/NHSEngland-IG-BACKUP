## `telecom`

<b>Definition:</b>

At least one **telecom** number **MUST** be provided.

Contact details that are specific to the role/location/service. Often practitioners have a dedicated line for each location (or service) that they work at and need to be able to define separate contact details for each of these.

This is not the personnel contact number of the Practitioner, it the contact number for the practitioner in this role and may be the phone number of the clinic, main or branch surgery.