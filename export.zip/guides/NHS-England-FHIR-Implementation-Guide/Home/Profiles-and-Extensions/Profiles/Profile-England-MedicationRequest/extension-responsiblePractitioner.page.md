## `extension:responsiblePractitioner`

<b>Definition:</b><br>

Must only be populated if the  `requester` can not be responsible for the prescription, i.e. they would not be named as the prescriber on the FP10.

---