## `extension:prescriptionTaskStatusReason`

<b>Definition:</b><br>

The status history within EPS is primarily a technical Status and the statusReason will reflect current clinical status of the order.

---
