## `subject`

<b>Definition</b><br>


A resource reference to a Patient with a traced NHS Number is required, an untraced NHS Number **MUST NOT** be used.

---

