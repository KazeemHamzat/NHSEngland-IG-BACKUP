## `extension:prescriptionEndorsement`

<b>Definition:</b><br>
The codes are contained in the valueset

| Code| Dispaly | 
|--
|cc|Contraceptive |
|FS| Sexual Health |
|ACBS|Advisory Committee on Borderline Substances. Part XV Drug Tariff| 
|SLS|Selected List Scheme.Part XVIIIB Drug Tariff| 
|AF|Food replacement/food supplement products.| 

---