## `extension:dispensingInformation`

<b>Definition:</b>

This extension is used in `continuous-repeat-dispensing` prescriptions sent by EPS to dispensing systems to convey information on prior dispensed medications.

---