## Bindings (differential)

More information about the bindings to NHS England ValueSets can be found below.

<table class="assets">
<tr>
<th width="30%">Context</th>
<th width="20%">Strength</th>
<th width="50%">Link</th>
</tr>
<tr>
<td><code>MessageHeader.event[x]<code></td>
<td>required</td>
<td>{{pagelink:ValueSet-England-MessageEvents}}</td>
</tr>
<tr>
<td><code>MessageHeader.reason<code></td>
<td>required</td>
<td>{{pagelink:ValueSet-England-MessageReasonCode}}</td>
</tr>
</table>

---