## `location`

<b>Definition</b><br>

Country where the vaccination took place. This should follow<a href="https://build.fhir.org/valueset-country.html" target="_blank">Using ISO 3166 Country Codes with FHIR</a> or a SNOMED Country Code.

---