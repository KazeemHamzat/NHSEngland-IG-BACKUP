## `doseQuantity`

<b>Definition</b><br>

A dm+d (SNOMED) Concept ID value representing the Unit of measure used.

For COVID-19 a reference set has been published here: https://dd4c.digital.nhs.uk/dd4c/publishedmetadatas/intid/980?size=10


```json

 "doseQuantity": {
        "value": 1,
        "unit": "pre-filled disposable injection",
        "system": "http://snomed.info/sct",
        "code": "3318611000001100"
    },
```
---