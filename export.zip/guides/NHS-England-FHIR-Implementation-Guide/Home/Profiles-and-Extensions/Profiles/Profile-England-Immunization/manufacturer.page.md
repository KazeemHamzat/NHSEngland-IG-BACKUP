## `manufacturer`

<b>Definition</b><br>

Manufacturer of vaccine product. Only the `display` is expected to be populated.

```json

"manufacturer": {
        "display": "DREAMLAND Pharmaceuticals Ltd"
    },
```

---