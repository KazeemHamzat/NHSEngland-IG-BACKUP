## `lotNumber`

<b>Definition</b><br>

Where status=`completed` this is Mandatory.
This should be captured at source ideally via use of automated scanning technology (GS1 GTIN / NTIN standard).

```json

   "lotNumber": "R04X",
```

---