## `intent`

<b>Definition:</b><br>

In **e-RS** default to `order`.

---