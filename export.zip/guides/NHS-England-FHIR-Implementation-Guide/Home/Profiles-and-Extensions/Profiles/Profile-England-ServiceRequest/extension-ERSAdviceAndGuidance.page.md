## `extension:ERSAdviceAndGuidance`

```json
"extension": [
        {
            "url": "https://fhir.nhs.uk/StructureDefinition/Extension-England-ERSReferral",
            "extension": [
                {
                    "url": "sourceSystem",
                    "valueCode": "ers"
                },
                {
                    "url": "status",
                    "valueCode": "unbooked"
                }
            ]
        }
],
```

---