## `identifier`

<b>Definition:</b><br>

Identifiers assigned to this order instance by the orderer and/or the receiver and/or order fulfiller.

```json
"identifier": [
                    {
                        "system": "https://fhir.nhs.uk/Id/UBRN",
                        "value": "111111111112"
                    }
                ],
```
---