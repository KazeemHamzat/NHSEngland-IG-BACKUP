## `extension:ERSServiceRequestState`

<b>Definition:</b><br>

e-RS representation of the state of the referral

---