## `reasonCode`

<b>Definition:</b><br>

An explanation or justification for why this service is being requested in coded or textual form. This is often for billing purposes. May relate to the resources referred to in supportingInfo.

```json
"reasonCode":  [
        {
            "coding":  [
                {
                    "system": "http://snomed.info/sct",
                    "code": "271835004",
                    "display": "Abdominal distension, gaseous"
                }
            ],
            "text": "Swollen abdomen"
        }
    ]
```

---