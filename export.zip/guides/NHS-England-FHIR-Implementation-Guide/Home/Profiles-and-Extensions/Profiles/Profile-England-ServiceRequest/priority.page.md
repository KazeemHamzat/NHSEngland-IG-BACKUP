## `priority`

<b>Definition:</b><br>

Request Priority Code. Code for the priority of the referral set by the Referring Clinician.

```json
 "priority": "routine",
```

---