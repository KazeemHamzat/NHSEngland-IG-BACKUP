## `authoredOn`

<b>Definition:</b><br>

Date the referral was initiated in e-RS.

```json
"authoredOn": "2022-01-11T16:40:00+00:00",
```
---