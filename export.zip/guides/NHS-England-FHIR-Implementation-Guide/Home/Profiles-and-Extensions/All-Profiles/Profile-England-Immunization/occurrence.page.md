## `occurence`

<b>Definition</b><br>

The date and time on which the vaccination intervention was carried out or was meant to be administered.

---
