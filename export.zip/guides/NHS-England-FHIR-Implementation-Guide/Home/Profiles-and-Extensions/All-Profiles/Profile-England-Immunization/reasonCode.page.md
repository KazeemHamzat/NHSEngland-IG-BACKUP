## `reasonCode`

<b>Definition</b><br>

A SNOMED Concept Id. For COVID19 and Flu see https://digital.nhs.uk/developer/api-catalogue/vaccination

---