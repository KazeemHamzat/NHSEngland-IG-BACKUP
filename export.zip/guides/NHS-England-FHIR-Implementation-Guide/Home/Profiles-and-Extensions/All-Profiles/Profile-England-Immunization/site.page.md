## `site`

<b>Definition</b><br>

Body site vaccine was administered into. A SNOMED Concept ID value from UK published reference set “Vaccine body site of administration simple reference set” (1127941000000100) should be used {{link:https://fhir.hl7.org.uk/ValueSet/UKCore-BodySite}}

---