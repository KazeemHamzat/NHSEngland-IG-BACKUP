## `patient`

<b>Definition</b><br>

A traced NHS Number **SHOULD** be provided and when applicable a resource reference to the Patient resource.

---