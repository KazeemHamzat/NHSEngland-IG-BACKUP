## `recorded`

<b>Definition</b><br>

The date that the vaccination administered (procedure) or not administered (situation) was recorded in the source system.

---