## `expirationDate`

<b>Definition</b><br>

Shorter date of either:

- Manufacturer expiry date of the vaccine
- Coronavirus point of care sites will only put in the defrost expiry date

---