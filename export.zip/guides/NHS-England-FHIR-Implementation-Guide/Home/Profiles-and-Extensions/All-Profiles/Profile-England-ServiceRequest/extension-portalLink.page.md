## `extension:portalLink`

<b>Definition:</b><br>

Deep Link into the specific landing page in MYR.

---