## `performerType`

<b>Definition:</b><br>

ERS

Specialty used to search for the shortlisted service(s) (if one was used)

---