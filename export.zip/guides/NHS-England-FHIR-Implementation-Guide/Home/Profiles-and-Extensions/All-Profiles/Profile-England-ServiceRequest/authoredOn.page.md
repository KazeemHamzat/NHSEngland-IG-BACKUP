## `authoredOn`

<b>Definition:</b><br>

Date the referral was initiated in e-RS.

---