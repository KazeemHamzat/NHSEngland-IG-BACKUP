## `name`

<b>Definition:</b>

The ODS/SDS name of the Organisation.

---

