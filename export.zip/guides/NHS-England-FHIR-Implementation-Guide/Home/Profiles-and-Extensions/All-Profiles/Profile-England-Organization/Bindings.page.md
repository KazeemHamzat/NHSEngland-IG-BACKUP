## Bindings (differential)

More information about the bindings to England ValueSets can be found below.

<table class="assets">
<tr>
<th width="30%">Context</th>
<th width="20%">Strength</th>
<th width="50%">Link</th>
</tr>
<tr>
<td><code>Organization.type</code></td>
<td>preferred</td>
<td>{{pagelink:ValueSet-England-OrganisationRole}}</td>
</tr>
</table>

---