## `partOf`

<b>Definition:</b>

Recommended mandatory for primary care organisations.