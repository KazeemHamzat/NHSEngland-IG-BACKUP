## Constraints (differential)

More information about the constraints on the <code>England-Organization</code> profile can be found below.

<table class="assets" title="Constraints list">
<tr>
<th class="width15">Key</th>
<th class="width10">Severity</th>
<th class="width30">Expression</th>
<th class="width45">Human Description</th>
</tr>
<tr>
<td>nhse-org-001</td>
<td>warning</td>
<td>display.exists()</td>
<td>partOf.display - a display name should be provided</td>
</tr>
</table>

---