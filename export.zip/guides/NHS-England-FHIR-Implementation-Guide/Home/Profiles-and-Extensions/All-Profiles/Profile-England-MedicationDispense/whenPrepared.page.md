## `whenPrepared`

<b>Definition:</b><br>

The time when the dispensed product was packaged and reviewed.

---