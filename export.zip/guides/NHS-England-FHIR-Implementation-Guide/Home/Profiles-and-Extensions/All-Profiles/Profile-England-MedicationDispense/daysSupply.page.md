## `daysSupply`

<b>Definition:</b><br>

The amount of medication expressed as a timing amount.

---