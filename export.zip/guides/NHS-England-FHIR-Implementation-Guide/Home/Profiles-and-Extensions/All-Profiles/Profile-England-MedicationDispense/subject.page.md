## `subject`

<b>Definition:</b><br>

A reference to the patient via a traced NHS Number is required, an untraced NHS Number MUST NOT be used. 

---