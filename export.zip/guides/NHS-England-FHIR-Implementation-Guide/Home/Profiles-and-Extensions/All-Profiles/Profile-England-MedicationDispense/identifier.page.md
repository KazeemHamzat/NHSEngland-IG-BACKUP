## `identifier`

<b>Definition:</b><br>

Each MedicationDispense MUST be identified by an Universal Unique Identifiers (UUIDs) with a system of https://fhir.nhs.uk/Id/prescription-dispense-item-number

UUID example (for illustration purposes only);

***4509B70D-D8B8-EA03-1105-64557CB54A29***

---