## `extension:preferredDispenserOrganization`

<b>Definition:</b>

A patient's preferred dispensing organisation.

---