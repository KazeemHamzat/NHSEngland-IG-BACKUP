## `multipleBirth[x]`

<b>Definition:</b>

The order in which the patient was born, with 1 indicating the first or only birth in the sequence, 2 indicating the second birth in the sequence, 3 indicating the third, and so on up to 7.

There are two other valid values; 8 meaning Not applicable and 9 meaning Not known.

1 ≤ value ≤ 9

---