## `medication[x]`

<b>Definition</b><br>

Only Virtual Medical Products (VMP) and Actual Medical Products (AMP) can be used.

--- 