## `courseOfTherapyType`

<b>Definition</b><br>

A course of therapy for a medication request.

---