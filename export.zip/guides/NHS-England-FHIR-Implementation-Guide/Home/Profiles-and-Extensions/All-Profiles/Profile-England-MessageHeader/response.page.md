## `response`

<b>Definition</b><br>

If the message is a response to a previous message, the response.identifier MUST match the previous request messages Bundle.identifier Correlation-ID.

---