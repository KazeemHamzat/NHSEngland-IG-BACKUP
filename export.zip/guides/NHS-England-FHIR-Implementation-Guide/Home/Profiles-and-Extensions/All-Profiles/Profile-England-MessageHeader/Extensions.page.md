## Extensions

More information about the extensions can be found using the links below.

<table class="assets" title="Extensions list">
<tr>
<th class="width20">Extension</th>
<th class="width20">Context</th>
<th class="width30">Link</th>
<th class="width30">Comment</th>
</tr>
<tr>
<td>senderLocalPart</td>
<td>MessageHeader</td>
<td>{{pagelink:Extension-England-MessageHeaderLocalPart}}</td>
<td></td>
</tr>
<tr>
<td>receiverLocalPart</td>
<td>MessageHeader</td>
<td>{{pagelink:Extension-England-MessageHeaderMessageID}}</td>
<td></td>
</tr>
<tr>
<td>replacementOf</td>
<td>MessageHeader</td>
<td>{{pagelink:Extension-England-MessageHeaderReplacement}}</td>
<td></td>
</tr>
</table>

---