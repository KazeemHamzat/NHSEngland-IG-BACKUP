## `type`

<b>Definition:</b>

Type **SHOULD** be populated.

### `type.coding:eRSAppointmentType`

Appointment type e.g. telephone/video (only applicable and mandatory if Service Type is Appointment Request, not applicable to Service Type of Triage Request)

---

