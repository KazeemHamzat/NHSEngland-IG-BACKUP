## `providedBy`

<b>Definition:</b>

It is recommended an *identifier reference* using ODS code is used. 

---

