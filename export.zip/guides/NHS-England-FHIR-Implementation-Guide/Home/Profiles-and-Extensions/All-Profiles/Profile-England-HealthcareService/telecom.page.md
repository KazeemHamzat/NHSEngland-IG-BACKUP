## `telecom`

<b>Definition:</b>

Contact details for the clinic or service.

---

