## `availableTime`

<b>Definition:</b>

Opening times for the clinic or service.

---

