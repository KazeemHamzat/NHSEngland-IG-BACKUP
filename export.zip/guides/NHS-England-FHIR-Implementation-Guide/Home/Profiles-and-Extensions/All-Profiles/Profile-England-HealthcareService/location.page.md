## `location`

<b>Definition:</b>

Reference to a location. ODS codes may be used, however this may differ from Directory of Services and so DoS addresses are preferred.

---

