## `identifier`

<b>Definition:</b><br>

For EPS

A single identifier MUST be present and the value must be a UUID.

---