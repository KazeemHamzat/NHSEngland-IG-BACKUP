## `effective[x]`

<b>Definition:</b><br>

The date and time the result was asserted.

---