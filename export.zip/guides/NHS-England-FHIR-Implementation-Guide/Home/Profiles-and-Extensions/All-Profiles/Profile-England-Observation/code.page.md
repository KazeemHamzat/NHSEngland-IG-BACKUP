## `code`

<b>Definition:</b><br>

Type of observation, for COVID-19 see [Observation Definition](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/ObservationDefinition/ObservationDefinition.guide.md) for `code` values.

---