## `status`

<b>Definition:</b><br>

The status of the result value.

For COVID-19 Test History the status of the observation will always be final.

---