## `category`

<b>Definition:</b><br>

This is an optional element. If used the category will always be <code>laboratory</code>.

For COVID-19 Tests, the ValueSet SHOULD be used to indicate which test pillar the observation originated.

---