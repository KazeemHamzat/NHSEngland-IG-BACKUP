## `identifier`

<b>Definition:</b><br>

A unique identifier assigned to this observation.

---