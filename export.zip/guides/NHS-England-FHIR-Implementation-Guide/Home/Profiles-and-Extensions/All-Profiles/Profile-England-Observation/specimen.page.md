## `specimen`

<b>Definition:</b><br>

For COVID-19 Test History. The identifier of the specimen used for the test.

---