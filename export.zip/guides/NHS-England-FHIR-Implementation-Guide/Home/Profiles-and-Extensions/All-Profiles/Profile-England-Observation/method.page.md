## `method`

<b>Definition:</b><br>

The name of the test that was performed, this is a SNOMED CT concept.

---