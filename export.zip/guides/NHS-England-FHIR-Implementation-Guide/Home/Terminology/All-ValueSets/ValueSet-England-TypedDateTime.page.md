---
subject: https://fhir.nhs.uk/England/ValueSet/England-TypedDateTime
---
## England Typed Date Time

{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}