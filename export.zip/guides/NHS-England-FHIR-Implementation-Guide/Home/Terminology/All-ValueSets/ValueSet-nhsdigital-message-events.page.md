---
subject: https://fhir.nhs.uk/ValueSet/NHSDigital-message-events
---
## Message Events

{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}

<div id="Feedback" class="tabcontent">
<h4><a href='https://simplifier.net/NHS-England-Implementation-Guide/ValueSet-nhsdigital-message-events/~issues?level=File' target="_blank">Propose a change to ValueSet-NHSMessageEvents</a></h4>
</div>
