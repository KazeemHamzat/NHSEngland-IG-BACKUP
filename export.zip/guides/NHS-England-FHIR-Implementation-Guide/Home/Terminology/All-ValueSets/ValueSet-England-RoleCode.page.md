---
subject: https://fhir.nhs.uk/England/ValueSet/England-RoleCode
---
## England-ODSRoleCode

{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}
