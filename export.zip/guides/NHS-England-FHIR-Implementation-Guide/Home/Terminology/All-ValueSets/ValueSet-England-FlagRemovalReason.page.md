---
subject: https://fhir.nhs.uk/England/ValueSet/England-FlagRemovalReason
---
## England Flag Removal Reason

{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}

<div id="Feedback" class="tabcontent">
<h4><a href='https://simplifier.net/NHS-England-Implementation-Guide/ValueSet-England-FlagRemovalReason/~issues?level=File' target="_blank">Propose a change to ValueSet-England-Flag-Removal-Reason </a></h4>
</div>
