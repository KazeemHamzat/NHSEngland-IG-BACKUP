---
subject: https://fhir.nhs.uk/England/ValueSet/England-FlagRemovalReason
---
## England Flag Removal Reason

{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}

