---
subject: https://fhir.nhs.uk/England/ValueSet/England-OrganisationRoleCode
---
## England Organisation Role Code
{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}
