---
subject: https://fhir.nhs.uk/England/ValueSet/England-OrganisationRole
---
## England Organisation Role

{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}

<div id="Feedback" class="tabcontent">
<h4><a href='https://simplifier.net/NHS-England-Implementation-Guide/ValueSet-England-OrganisationRole/~issues?level=File' target="_blank">Propose a change to ValueSet-England-Organisation-Role </a></h4>
</div>