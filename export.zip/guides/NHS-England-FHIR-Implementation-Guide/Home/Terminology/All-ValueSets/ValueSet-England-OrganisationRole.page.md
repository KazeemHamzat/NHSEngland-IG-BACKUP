---
subject: https://fhir.nhs.uk/England/ValueSet/England-OrganisationRole
---
## England Organisation Role
{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}
