---
subject: https://fhir.nhs.uk/England/ValueSet/England-ChildProtectionPlan
---

## England Child Protection Plan

{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}