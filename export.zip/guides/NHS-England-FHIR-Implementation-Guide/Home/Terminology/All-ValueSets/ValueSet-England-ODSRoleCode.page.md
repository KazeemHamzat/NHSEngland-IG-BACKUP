---
subject: https://fhir.nhs.uk/England/ValueSet/England-ODSRoleCode
---
## England-ODSRoleCode

{{page:Home/Terminology/All-ValueSets/ValueSetTemplate.page.md}}
