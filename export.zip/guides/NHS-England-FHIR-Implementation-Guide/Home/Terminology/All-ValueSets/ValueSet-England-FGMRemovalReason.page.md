---
subject: https://fhir.nhs.uk/England/ValueSet/England-FGMRemovalReason
---
## England-FGMRemovalReason

{{page:Home/Terminology/All-ValueSets/ValueSetTemplate.page.md}}
<br>

