---
subject: https://fhir.nhs.uk/England/ValueSet/England-FGMRemovalReason
---
## England-FGMRemovalReason

{{render:FHIR-Implementation-Guide-Home-Terminology-All-ValueSets-ValueSetTemplate}}

