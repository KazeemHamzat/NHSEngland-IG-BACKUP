---
subject: https://fhir.nhs.uk/England/CodeSystem/England-ODSRoleCode
---
## England-ODSRoleCode


@```
from
	CodeSystem
where
	name = 'EnglandODSRoleCode'
select
	Description: description
```

{{page:home/terminology/all-codesystems/codesystemtemplate.page.md}}