---
subject: https://fhir.nhs.uk/England/CodeSystem/England-ODSOrganisationRole
---
## England ODS Organisation Role


@```
from
	CodeSystem
where
	name = 'EnglandODSOrganisationRole'
select
	Description: description
```

{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}