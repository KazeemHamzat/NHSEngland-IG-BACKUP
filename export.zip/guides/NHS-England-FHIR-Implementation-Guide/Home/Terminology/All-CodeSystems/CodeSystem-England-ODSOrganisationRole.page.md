---
subject: https://digital.nhs.uk/services/organisation-data-service/CodeSystem/ODSOrganisationRole
issue: CodeSystem-England-ODSOrganisationRole
---
## England ODS Organisation Role


{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
