---
subject: https://fhir.nhs.uk/England/CodeSystem/England-RoleCode
---
## England-ODSRoleCode


@```
from
	CodeSystem
where
	name = 'EnglandODSRoleCode'
select
	Description: description
```

{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}