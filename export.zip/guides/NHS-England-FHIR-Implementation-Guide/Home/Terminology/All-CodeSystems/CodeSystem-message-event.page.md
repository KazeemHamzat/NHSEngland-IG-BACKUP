---
subject: https://fhir.nhs.uk/CodeSystem/message-event
issue: codesystem-message-events
---
## Message Event


{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}