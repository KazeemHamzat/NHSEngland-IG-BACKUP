---
subject: https://fhir.nhs.uk/CodeSystem/message-reason-bars
issue: CodeSystem-England-MessageReasonBARS
---
## England Message Reason BARS

{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
