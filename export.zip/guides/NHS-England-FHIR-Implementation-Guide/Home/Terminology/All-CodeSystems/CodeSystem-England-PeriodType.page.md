---
subject: https://fhir.nhs.uk/England/CodeSystem/England-PeriodType
issue: CodeSystem-England-PeriodType
---
## England Period Type


{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
