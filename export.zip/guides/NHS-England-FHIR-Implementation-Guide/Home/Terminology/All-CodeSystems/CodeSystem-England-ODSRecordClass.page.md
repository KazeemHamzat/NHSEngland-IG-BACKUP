---
subject: https://digital.nhs.uk/services/organisation-data-service/CodeSystem/ODSRecordClass
issue: CodeSystem-England-ODSRecordClass
---

## England ODS Record Class


{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
