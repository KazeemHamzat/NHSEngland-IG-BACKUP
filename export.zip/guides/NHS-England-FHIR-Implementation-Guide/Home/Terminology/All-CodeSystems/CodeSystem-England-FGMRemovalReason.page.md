---
subject: https://fhir.nhs.uk/England/CodeSystem/England-FGMRemovalReason
---
## England-FGMRemovalReason


@```
from
	CodeSystem
where
	name = 'EnglandFGMRemovalReason'
select
	Description: description
```

{{page:home/terminology/all-codesystems/codesystemtemplate.page.md}}


