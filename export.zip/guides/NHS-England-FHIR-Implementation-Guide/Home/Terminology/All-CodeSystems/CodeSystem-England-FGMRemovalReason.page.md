---
subject: https://fhir.nhs.uk/England/CodeSystem/England-FGMRemovalReason
---
## England-FGMRemovalReason


@```
from
	CodeSystem
where
	name = 'EnglandFGMRemovalReason'
select
	Description: description
```

{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}

