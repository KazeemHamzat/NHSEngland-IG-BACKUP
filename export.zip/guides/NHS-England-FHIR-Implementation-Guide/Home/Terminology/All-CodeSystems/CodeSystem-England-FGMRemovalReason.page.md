---
subject: https://fhir.nhs.uk/England/CodeSystem/England-FGMRemovalReason
issue: CodeSystem-England-FGMRemovalReason
---
## England FGM Removal Reason

{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
