## {{page-title}}


<table class="regular" style="width:100%">
 <thead>
   <tr>
     <th >Status</th>
     <th >Version</th>
     <th >Date</th>
   </tr>
 </thead>
 <tbody>
   <tr>
    <td>Current</td>
    <td><a href="https://simplifier.net/guide/NHSDigital">2.3.0</td>
   <td>8 Dec 2021</td>
   </tr>
    <tr>
    <td></td>
    <td><a href="https://simplifier.net/guide/NHSDigital-2.1.50">2.1.50-discovery</td>
   <td>14 Sept 2021</td>
   </tr>
   </tbody>
</table>