## {{page-title}}

<br />
<table class="regular assets">
<tr>
<th>Example Name</th>
<th>ID</th>
<th>Resource</th>
</tr>

<tr>
<td cosplan="3">There are no NHS England IG examples</td>
</tr>

</table>