## {{page-title}}

<br />
<table class="regular assets">
<tr>
<th>Example Name</th>
<th>ID</th>
<th>Resource</th>
</tr>

<tr>
<td cosplan="3"><a href="https://simplifier.net/guide/Female-Genital-Mutilation-Implementation-Guide2/Home/Build/Examples?version=current">FGM Examples</a></td>
</tr>

<tr>
<td cosplan="3"><a href="https://simplifier.net/guide/Child-Protection---Information-Sharing--CP-IS--API-Producer-Impl/Home/Examples?version=current">CP-IS Examples</a></td>
</tr>

</table>