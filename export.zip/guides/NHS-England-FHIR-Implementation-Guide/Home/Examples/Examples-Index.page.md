## {{page-title}}


<table class="regular assets">
<tr>
<th>Example Name</th>
<th>ID</th>
<th>Resource</th>
</tr>

<tr>
<td>{{pagelink:Example-England-OperationOutcome-PatientFirstNameValidation}}</td>
<td>England-OperationOutcome-PatientFirstNameValidation-Example</td>
<td>OperationOutcome</td>
</tr>

<tr>
<td>{{pagelink:Example-England-OperationOutcome-PatientDetailsValidation}}</td>
<td>England-OperationOutcome-PatientDetailsValidation-Example</td>
<td>OperationOutcome</td>
</tr>

<tr>
<td>{{pagelink:Example-England-Organization-GPPractice}}</td>
<td>England-Organization-GPPractice-Example</td>
<td>Organization</td>
</tr>

<tr>
<td>{{pagelink:Example-England-Organization-NHSICS}}</td>
<td>England-Organization-NHSICS-Example</td>
<td>Organization</td>
</tr>

<tr>
<td>{{pagelink:Example-England-Organization-ODSAPIOrganizationR4LeedsCCG}}</td>
<td>England-England-Organization-ODSAPIOrganizationR4LeedsCCG</td>
<td>Organization</td>
</tr>

<tr>
<td>{{pagelink:Example-England-Organization-ODSAPIOrganizationR4ReadResponse}}</td>
<td>England-Organization-ODSAPIOrganizationR4ReadResponse</td>
<td>Organization</td>
</tr>

<tr>
<td>{{pagelink:Example-England-Organization-OrganisationPrison}}</td>
<td>England-Organization-OrganisationPrison</td>
<td>Organization</td>
</tr>

Note: Every effort has been made to ensure that the examples are correct and useful.
</table>