## {{page-title}}


<table class="regular assets">
<tr>
<th>Example Name</th>
<th>ID</th>
<th>Format</th>
</tr>

<tr>
<td>{{pagelink:Example-England-OperationOutcome-PatientFirstNameValidation}}</td>
<td>England-OperationOutcome-PatientFirstNameValidation-Example</td>
<td><a href="https://simplifier.net/NHS-England-Implementation-Guide/England-OperationOutcome-PatientFirstNameValidation-Example/~xml" target="_blank">XML</a>  <a href="https://simplifier.net/NHS-England-Implementation-Guide/England-OperationOutcome-PatientFirstNameValidation-Example/~json" target="_blank">JSON</a></td>
</tr>

<tr>
<td>{{pagelink:Example-England-OperationOutcome-PatientDetailsValidation}}</td>
<td>England-OperationOutcome-PatientDetailsValidation-Example</td>
<td><a href="https://simplifier.net/NHS-England-Implementation-Guide/England-OperationOutcome-PatientDetailsValidation-Example/~xml" target="_blank" >XML</a>  <a href="https://simplifier.net/NHS-England-Implementation-Guide/England-OperationOutcome-PatientDetailsValidation-Example/~json" target="_blank">JSON</a></td>
</tr>

</table>