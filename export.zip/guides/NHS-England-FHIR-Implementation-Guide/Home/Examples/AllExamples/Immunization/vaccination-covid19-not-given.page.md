### vaccination-covid19-not-given

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:251d4f32-e9ae-41f2-bb63-54e692195cc2}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:251d4f32-e9ae-41f2-bb63-54e692195cc2}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:251d4f32-e9ae-41f2-bb63-54e692195cc2}}
    </div>
  </div>
</div>
