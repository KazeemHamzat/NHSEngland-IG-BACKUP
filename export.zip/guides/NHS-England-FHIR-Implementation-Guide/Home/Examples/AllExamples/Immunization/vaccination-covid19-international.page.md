### {{page-title}}

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:bd2ec326-7570-46bd-98a0-02c4b924c79d}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:bd2ec326-7570-46bd-98a0-02c4b924c79d}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:bd2ec326-7570-46bd-98a0-02c4b924c79d}}
    </div>
  </div>
</div>