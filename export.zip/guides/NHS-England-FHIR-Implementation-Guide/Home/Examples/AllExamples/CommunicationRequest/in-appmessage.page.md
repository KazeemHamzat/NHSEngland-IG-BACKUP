### in-app message

NHS App Patient in-app message


<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:941f9751-aa2a-4749-88c1-201266f7b538}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:941f9751-aa2a-4749-88c1-201266f7b538}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:941f9751-aa2a-4749-88c1-201266f7b538}}
    </div>
  </div>
</div>