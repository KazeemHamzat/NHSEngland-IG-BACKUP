### push notification

NHS App Patient push notification

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:d4df7fed-adac-401e-86a3-9f80d115d2e4}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:d4df7fed-adac-401e-86a3-9f80d115d2e4}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:d4df7fed-adac-401e-86a3-9f80d115d2e4}}
    </div>
  </div>
</div>
