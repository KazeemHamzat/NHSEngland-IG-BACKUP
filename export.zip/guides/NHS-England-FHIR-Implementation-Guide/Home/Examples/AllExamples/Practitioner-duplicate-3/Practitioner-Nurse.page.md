### Practitioner Nurse



<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:78f00516-fc22-416b-b8b5-f4d2fd915a14}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:78f00516-fc22-416b-b8b5-f4d2fd915a14}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:78f00516-fc22-416b-b8b5-f4d2fd915a14}}
    </div>
  </div>
</div>