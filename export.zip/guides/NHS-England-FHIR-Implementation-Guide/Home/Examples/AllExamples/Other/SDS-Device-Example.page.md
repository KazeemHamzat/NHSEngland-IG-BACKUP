### SDS-Device

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:f0f0e921-92ca-4a88-a550-2dbb36f703af-duplicate-2}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:f0f0e921-92ca-4a88-a550-2dbb36f703af-duplicate-2}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:f0f0e921-92ca-4a88-a550-2dbb36f703af-duplicate-2}}
    </div>
  </div>
</div>
