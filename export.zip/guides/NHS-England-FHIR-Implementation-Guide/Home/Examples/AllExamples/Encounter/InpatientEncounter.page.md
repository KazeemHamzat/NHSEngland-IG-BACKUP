### Inpatient Encounter

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> Experimental. This page is for illustration of a concept</div>

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:9d222207-7b26-42a0-9abe-f9883a330662}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:9d222207-7b26-42a0-9abe-f9883a330662}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:9d222207-7b26-42a0-9abe-f9883a330662}}
    </div>
  </div>
</div>
