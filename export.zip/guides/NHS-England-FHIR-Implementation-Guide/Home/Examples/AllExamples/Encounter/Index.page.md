### Encounter

- {{pagelink:InpatientEncounter}}