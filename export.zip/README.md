# FHIR Specification

This repository is used in the [NHS Digital FHIR Implementation Guide](https://simplifier.net/guide/NHSDigital/Home) 


 [![NHS Digital IOPS Validation)](https://github.com/NHSDigital/NHSDigital-FHIR-ImplementationGuide/actions/workflows/terminology.yml/badge.svg)](https://github.com/NHSDigital/NHSDigital-ImplementationGuide/actions/workflows/terminology.yml)


